uint8_t char_from_rust(uint8_t count);
