#![no_std]
#![no_main]

#[no_mangle]
pub extern "C" fn char_from_rust(count: u8) -> u8 {
    count % 2
}

use core::panic::PanicInfo;

#[panic_handler]
fn panic(_panic: &PanicInfo<'_>) -> ! {
    loop {}
}
