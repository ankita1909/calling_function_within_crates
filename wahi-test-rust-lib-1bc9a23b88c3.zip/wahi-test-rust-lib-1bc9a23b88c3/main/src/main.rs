extern crate lib;

fn main() {
    lib::p();
    println!("Hello, world!");
}
